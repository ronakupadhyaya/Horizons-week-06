# Week 6 Day 2 Exercises

## Morning videos & Individual exercises

[React Router Videos](videos)



## Pair programming exercises

[Redux Hangman](hangman)  
[React Router Directory](directory)  
[Bonus: Production Todo-Redux](./todo.md)

