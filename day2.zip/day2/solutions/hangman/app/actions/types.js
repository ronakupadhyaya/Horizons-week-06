export const FILTER = 'FILTER';
// MAN ACTION TYPES
export const STEP = 'STEP';

// BOARD ACTION TYPES
export const START = 'START';
export const GUESS = 'GUESS';
