import React from 'react';

const About = () =>
    <div>
        Redux Hangman, Horizons Edition
    </div>;


export default About;
