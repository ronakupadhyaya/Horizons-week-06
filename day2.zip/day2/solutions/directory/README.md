# Pair programming bonus exercise: Directory

## Goal

The goal of this exercise is to create a simple directory application using React Router. You can find a live example of the app at this url:  

[https://scenic-bryce-canyon-41169.herokuapp.com/](https://scenic-bryce-canyon-41169.herokuapp.com/)

Play around with the app for a bit to see all the pages. There are pages on `/`, `/directory`, `/directory/SOME_FIRST_NAME`, and `/directory/SOME_FIRST_NAME/SOME_LAST_NAME`.

## Part 1:
