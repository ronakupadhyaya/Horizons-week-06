'use strict';

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

//state contains current color, canvas color, and all the color options
var initState = { canvasColor: 'white',
  colors: ['white', 'blue', 'red', 'purple', 'green', 'orange'],
  currentIndex: 0 };

var colorPickerChange = function colorPickerChange() {
  return {
    type: 'COLOR_PICKER_CHANGE'
  };
};

var canvasColorChange = function canvasColorChange() {
  return {
    type: 'CANVAS_COLOR_CHANGE'
  };
};

var reducer = function reducer() {
  var state = arguments.length <= 0 || arguments[0] === undefined ? initState : arguments[0];
  var action = arguments[1];

  switch (action.type) {
    case 'COLOR_PICKER_CHANGE':
      var newState = Object.assign({}, state, { currentIndex: (state.currentIndex + 1) % state.colors.length });
      return newState;
    case 'CANVAS_COLOR_CHANGE':
      var newColor = Object.assign({}, state, { canvasColor: state.colors[state.currentIndex] });
      return newColor;
    case 'DELETE_COLOR':
      var deleted = Object.assign({}, state, { colors: state.colors.filter(function (color) {
          return color !== action.color;
        }) });
      return deleted;
    default:
      return state;
  }
};

var inlineStyle = function inlineStyle(color) {
  return {
    backgroundColor: color
  };
};

var Canvas = function (_React$Component) {
  _inherits(Canvas, _React$Component);

  function Canvas() {
    _classCallCheck(this, Canvas);

    return _possibleConstructorReturn(this, _React$Component.apply(this, arguments));
  }

  Canvas.prototype.render = function render() {
    return React.createElement(
      'div',
      { id: 'canvas', onClick: function onClick() {
          return store.dispatch(canvasColorChange());
        }, style: inlineStyle(store.getState().canvasColor) },
      React.createElement(
        'h1',
        null,
        ' I\'m the canvas '
      )
    );
  };

  return Canvas;
}(React.Component);

;

var ColorPicker = function (_React$Component2) {
  _inherits(ColorPicker, _React$Component2);

  function ColorPicker() {
    _classCallCheck(this, ColorPicker);

    return _possibleConstructorReturn(this, _React$Component2.apply(this, arguments));
  }

  ColorPicker.prototype.render = function render() {
    return React.createElement('div', { id: 'picker', onClick: function onClick() {
        return store.dispatch(colorPickerChange());
      }, style: inlineStyle(store.getState().colors[store.getState().currentIndex]) });
  };

  return ColorPicker;
}(React.Component);

;

var ColorButtons = function (_React$Component3) {
  _inherits(ColorButtons, _React$Component3);

  function ColorButtons() {
    _classCallCheck(this, ColorButtons);

    return _possibleConstructorReturn(this, _React$Component3.apply(this, arguments));
  }

  ColorButtons.prototype.render = function render() {
    var currState = store.getState();
    return React.createElement(
      'div',
      { id: 'buttons' },
      currState.colors.map(function (color) {
        return React.createElement(ColorButton, { color: color });
      })
    );
  };

  return ColorButtons;
}(React.Component);

;

var deleteColor = function deleteColor(color) {
  return {
    type: 'DELETE_COLOR',
    color: color
  };
};

var ColorButton = function (_React$Component4) {
  _inherits(ColorButton, _React$Component4);

  function ColorButton() {
    _classCallCheck(this, ColorButton);

    return _possibleConstructorReturn(this, _React$Component4.apply(this, arguments));
  }

  ColorButton.prototype.render = function render() {
    var _this5 = this;

    var currState = store.getState();
    return React.createElement(
      'div',
      null,
      React.createElement(
        'button',
        { onClick: function onClick() {
            return store.dispatch(deleteColor(_this5.props.color));
          } },
        ' ',
        this.props.color,
        ' '
      )
    );
  };

  return ColorButton;
}(React.Component);

;

var App = function (_React$Component5) {
  _inherits(App, _React$Component5);

  function App() {
    _classCallCheck(this, App);

    return _possibleConstructorReturn(this, _React$Component5.apply(this, arguments));
  }

  App.prototype.render = function render() {
    return React.createElement(
      'div',
      null,
      React.createElement(Canvas, null),
      React.createElement(ColorPicker, null),
      React.createElement(ColorButtons, null)
    );
  };

  return App;
}(React.Component);

;

var _Redux = Redux;
var createStore = _Redux.createStore;

var store = createStore(reducer);

var render = function render() {
  ReactDOM.render(React.createElement(App, null), document.getElementById('root'));
};

store.subscribe(render);
render();