"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

//Some basic setup - this looks different from the videos cause
//  we're using Codepen and importing works differently
var _ReactRouter = ReactRouter;
var Redirect = _ReactRouter.Redirect;
var _ReactRouterDOM = ReactRouterDOM;
var BrowserRouter = _ReactRouterDOM.BrowserRouter;
var Switch = _ReactRouterDOM.Switch;
var Route = _ReactRouterDOM.Route;
var Link = _ReactRouterDOM.Link;

//  Array of TAs and their speeds

var teamMembers = [{ name: "Syed",
  speed: 10 }, { name: "Nihar",
  speed: 20 }, { name: "Tom",
  speed: 314 }, { name: "Allie",
  speed: 4.6 }, { name: "Gisela",
  speed: 102.2 }, { name: "Graham",
  speed: 99 }, { name: "Jo",
  speed: 0.1 }, { name: "Jay",
  speed: 9999 }];

//DON'T TOUCH THIS

var Status = function (_React$Component) {
  _inherits(Status, _React$Component);

  function Status() {
    _classCallCheck(this, Status);

    return _possibleConstructorReturn(this, _React$Component.apply(this, arguments));
  }

  Status.prototype.render = function render() {
    if (this.props.location.pathname.length > 30) {
      return React.createElement(Redirect, { to: "/" });
    }
    return React.createElement(
      "div",
      null,
      "You are at: ",
      this.props.location.pathname
    );
  };

  return Status;
}(React.Component);

// A helper function that gets speed of a certain person:
//  getSpeedOf("Jay") => 9999, etc
//  If it encounters errors finding the speed, returns null

function getSpeedOf(person) {
  for (var i = 0; i < speeds.length; i++) {
    if (speeds[i].name == person) return speeds[i].speed;
  }
  return null;
}

// (suggested) Helpful Function to help with rendering final message
//  Input: two Strings, both should be names
//  Output: an appropriate message string ("P1 wins by x chicken legs!" etc)
function calcMessage(p1, p2) {}
/*
  MESSAGE CALCULATION HERE
*/

// (suggested) Component that renders a final result

var FinalResult = function (_React$Component2) {
  _inherits(FinalResult, _React$Component2);

  function FinalResult() {
    _classCallCheck(this, FinalResult);

    return _possibleConstructorReturn(this, _React$Component2.apply(this, arguments));
  }

  FinalResult.prototype.render = function render() {
    var players = this.props.match.url.split('/');
    var player1 = players[players.length - 2];
    var player2 = players[players.length - 1];
    var player1speed;
    var player2speed;
    teamMembers.map(function (member) {
      if (member.name === player1) {
        player1speed = member.speed;
      } else if (member.name === player2) {
        player2speed = member.speed;
      }
    });

    return React.createElement(
      "div",
      null,
      React.createElement(
        "p",
        null,
        "Player2 is: ",
        this.props.match.params.ta
      ),
      player1speed > player2speed ? React.createElement(
        "p",
        null,
        "P1 wins by ",
        player1speed - player2speed,
        " chicken legs!"
      ) : React.createElement(
        "p",
        null,
        "P2 wins by ",
        player2speed - player1speed,
        " chicken legs!"
      )
    );
  };

  return FinalResult;
}(React.Component);

// (suggested) Component that renders after first link clicked
//  should show second level links, as well as some final result

var P2Selection = function (_React$Component3) {
  _inherits(P2Selection, _React$Component3);

  function P2Selection() {
    _classCallCheck(this, P2Selection);

    return _possibleConstructorReturn(this, _React$Component3.apply(this, arguments));
  }

  P2Selection.prototype.render = function render() {
    var _this4 = this;

    return React.createElement(
      "div",
      null,
      React.createElement(
        "p",
        null,
        "Player1 is: ",
        this.props.match.params.ta
      ),
      React.createElement(
        "h2",
        null,
        " Select your second player!"
      ),
      teamMembers.map(function (member) {
        return React.createElement(
          "li",
          { key: member.name },
          React.createElement(
            Link,
            { to: _this4.props.match.url + '/' + member.name },
            member.name
          )
        );
      }),
      React.createElement(Route, { path: this.props.match.url + '/:ta', component: FinalResult })
    );
  };

  return P2Selection;
}(React.Component);

var App = function (_React$Component4) {
  _inherits(App, _React$Component4);

  function App(props) {
    _classCallCheck(this, App);

    return _possibleConstructorReturn(this, _React$Component4.call(this, props));
  }

  App.prototype.render = function render() {
    return React.createElement(
      "div",
      null,
      React.createElement(Route, { path: "/", component: Status }),
      React.createElement(
        "h2",
        null,
        " Welcome to the chicken leg contest!"
      ),
      React.createElement(
        "h2",
        null,
        " Select your first player!"
      ),
      teamMembers.map(function (member) {
        return React.createElement(
          "li",
          { key: member.name },
          React.createElement(
            Link,
            { to: '/' + member.name },
            member.name
          )
        );
      }),
      React.createElement(Route, { path: "/:ta", component: P2Selection })
    );
  };

  return App;
}(React.Component);

ReactDOM.render(React.createElement(
  BrowserRouter,
  { basename: "/" },
  React.createElement(App, null)
), document.getElementById('root'));