const imgUrls = [
    'https://d3vv6lp55qjaqc.cloudfront.net/items/0r303q3V433l180r3T04/Image%202017-05-28%20at%208.21.20%20PM.png?v=e03b9d65',
    'https://d3vv6lp55qjaqc.cloudfront.net/items/0C462C3Z2I1m0P2B3Q06/Image%202017-05-28%20at%208.22.39%20PM.png?v=42b328bd',
    'https://d3vv6lp55qjaqc.cloudfront.net/items/180f2x1H212V2c0x3l3d/Screen%20Shot%202017-05-28%20at%208.23.35%20PM.png?v=dc7faa40',
    'https://d3vv6lp55qjaqc.cloudfront.net/items/0v091u1y0L2V1o303D2I/Screen%20Shot%202017-05-28%20at%208.24.11%20PM.png?v=b2135880',
    'https://cl.ly/171p1o461528/Image%202017-05-28%20at%208.25.49%20PM.png',
    'https://cl.ly/151P0M1E2f3n/Image%202017-05-28%20at%208.26.09%20PM.png',
    'https://cl.ly/2Q27011r022a/Image%202017-05-28%20at%208.26.23%20PM.png'
];

export default imgUrls;
